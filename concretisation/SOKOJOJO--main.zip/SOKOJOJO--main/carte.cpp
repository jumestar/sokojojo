#include "ext/json.hpp"
#include "carte.hpp"
#include <fstream>
#include <iostream>

using json = nlohmann::json;

Carte::Carte(const std::string& filename, int lvlId) : levelId(lvlId) {
    // Charger le fichier JSON
    std::ifstream file(filename);
    if (!file) {
        std::cerr << "Impossible d'ouvrir le fichier JSON de plateaux : " << filename << std::endl;
        std::exit(1);
    }

    json levelsData;
    file >> levelsData;  // Charger tous les niveaux

    bool levelFound = false;
    // Parcourir les niveaux pour trouver celui avec le bon id{
    if (levelsData["id"] == levelId) {
        loadLevelFromJson(levelsData);
        levelFound = true;
    }

    if (!levelFound) {
        std::cerr << "Niveau avec ID " << levelId << " non trouvé." << std::endl;
        std::exit(1);
    }
}
const std::vector<std::string> Carte::levelFiles = {
    "res/plateau1.json",
    "res/plateau2.json",
    "res/plateau3.json",
    "res/plateau4.json",
    "res/plateau5.json",
    "res/plateau6.json"
};

void Carte::loadLevelFromJson(const json& levelData) {
    rows = levelData["height"];
    cols = levelData["width"];
    depart = sf::Vector2i(levelData["spawn"]["x"], levelData["spawn"]["y"]);

    // Générer une grille de cases vides
    level = std::vector<std::string>(rows, std::string(cols, '.'));

    // Ajouter les murs
    for (const auto& wall : levelData["walls"]) {
        int x = wall["x"];
        int y = wall["y"];
        level[y][x] = '#';
    }

    // Ajouter les caisses
    for (const auto& box : levelData["boxes"]) {
        int x = box["x"];
        int y = box["y"];
        level[y][x] = 'B';
    }

    // Ajouter les objectifs
    for (const auto& target : levelData["targets"]) {
        int x = target["x"];
        int y = target["y"];
        level[y][x] = 'O';
    }

    // Position de départ du joueur
    // level[depart.y][depart.x] = '@';

    loadTextures();  // Charger les textures
}

void Carte::loadSelectedLevel(const std::string& filename, int selectedLevelId) {
    levelId = selectedLevelId;  // Mettre à jour levelId avec le niveau choisi
    
    // Charger le fichier JSON
    std::ifstream file(filename);
    if (!file) {
        std::cerr << "Impossible d'ouvrir le fichier JSON de plateaux : " << filename << std::endl;
        std::exit(1);
    }

    json levelsData;
    file >> levelsData;

    bool levelFound = false;
    for (const auto& levelData : levelsData["levels"]) {
        if (levelData["id"] == levelId) {
            loadLevelFromJson(levelData);
            levelFound = true;
            break;
        }
    }

    if (!levelFound) {
        std::cerr << "Niveau avec ID " << levelId << " non trouvé." << std::endl;
        std::exit(1);
    }
}

void Carte::loadTextures() {
    wallTex.loadFromFile("res/wall.png");
    floorTex.loadFromFile("res/empty.png");
    boxTex.loadFromFile("res/box.png");
    targetTex.loadFromFile("res/objective.png");
    boxOnTargetTex.loadFromFile("res/active.png");
}

void Carte::draw(sf::RenderWindow& window) {
    sf::Sprite sprite;
    sf::Uint8 cptObj{0};

    for (int y = 0; y < rows; ++y) {
        for (int x = 0; x < cols; ++x) {
            if (level[y][x] == '.') {
                sprite.setTexture(floorTex); // sol
                sprite.setPosition(x * tileSize, y * tileSize);
                window.draw(sprite);  
            } else if (level[y][x] == '#') {
                sprite.setTexture(wallTex); // mur
                sprite.setPosition(x * tileSize, y * tileSize);
                window.draw(sprite);
            } else if (level[y][x] == 'B') {
                sprite.setTexture(boxTex); // boite
                sprite.setPosition(x * tileSize, y * tileSize);
                window.draw(sprite);
            } else if (level[y][x] == 'O') {
                sprite.setTexture(targetTex); // objectif
                sprite.setPosition(x * tileSize, y * tileSize);
                window.draw(sprite);
                cptObj++;
            } else if (level[y][x] == '*') { 
                sprite.setTexture(boxOnTargetTex); // boite sur objectif
                sprite.setPosition(x * tileSize, y * tileSize);
                window.draw(sprite);  
            }
        }
    }
    if(cptObj == 0) // si tous les objectifs sont atteints
        m_won = true;
}