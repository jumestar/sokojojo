to do :

Bouton qui affiche règles+ vérifier le png +  bouton reset + json
