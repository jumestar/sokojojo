#pragma once

#include <SFML/Graphics.hpp>


class Menu 
{
    public:
        Menu(sf::RenderWindow& window);

        void drawMenu();
        void handleInput(sf::Event& event);
        void updateSelection(sf::Event& event);
        int getSelectedOption() const { return selectedOption; } // Getter pour l'option sélectionnée

        bool getRunning() const { return isRunning; } // Getter pour savoir si le jeu est lancé
        bool getLevelSelected() const { return isLevelSelection; } // Getter pour savoir si un niveau est sélectionné
        void setRunning(bool running); // Setter pour savoir si le jeu est lancé

        void drawVictory(sf::RenderWindow& window);
        void drawRestart(sf::RenderWindow& window);
        void drawInputs(sf::RenderWindow& window);
        void addInputs(sf::Keyboard::Key key);
        void resetInputs() { recentInputs.clear(); } // Setter pour les entrées récentes

    private:
        sf::RenderWindow& m_window;
        
        sf::Font m_font;
        sf::Text m_title;
        
        
        sf::Text m_playButton;
        sf::Text m_exitButton;
        sf::Text m_backButton;
        
        bool isRunning{false};
        
        bool isLevelSelection{false};
        int selectedOption{0};
        std::vector<sf::Text> levelButtons;
        
        void drawLevelSelection(); // Méthode pour dessiner le menu de sélection de niveau
        void loadResources();
        void drawMainMenu(); // Méthode pour dessiner le menu principal

        std::string keyToString(sf::Keyboard::Key key);
        std::vector<sf::Keyboard::Key> recentInputs;
};