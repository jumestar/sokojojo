#include "joueur.hpp"
#include <iostream>

Joueur::Joueur(Carte& carte, sf::Vector2i pos) : m_position(pos) {
    m_texture = std::make_unique<sf::Texture>(); 
    if (!m_texture->loadFromFile("res/jojo.png")) {
        std::cerr << "Erreur de chargement de la texture" << std::endl;
        return;
    }
    m_sprite = std::make_unique<sf::Sprite>(*m_texture); 
    m_sprite->setScale(1.0f, 1.0f);  
}

sf::Vector2i Joueur::getPosition() const {
    return m_position;
}

void Joueur::draw(sf::RenderWindow& window) {
    m_sprite->setPosition(m_position.x * 64, m_position.y * 64);
    window.draw(*m_sprite);
}

bool Joueur::estLibre(char c) const 
{
    return c == '.' || c == 'O';
};

void Joueur::update(Carte& carte, sf::Keyboard::Key key) {
    sf::Vector2i dir(0, 0);

    if (key == sf::Keyboard::Right) dir.x = 1;
    else if (key == sf::Keyboard::Left) dir.x = -1;
    else if (key == sf::Keyboard::Up) dir.y = -1;
    else if (key == sf::Keyboard::Down) dir.y = 1;
    else return;

    sf::Vector2i nextPos = m_position + dir;
    sf::Vector2i afterPos = m_position + dir * 2;

    if (nextPos.y < 0 || nextPos.y >= carte.getHauteur() ||
        nextPos.x < 0 || nextPos.x >= carte.getLargeur())
        return;

    char& current = carte.getMap()[m_position.y][m_position.x];
    char& next = carte.getMap()[nextPos.y][nextPos.x];
    char after = ' ';

    if (afterPos.y >= 0 && afterPos.y < carte.getHauteur() &&
        afterPos.x >= 0 && afterPos.x < carte.getLargeur())
        after = carte.getMap()[afterPos.y][afterPos.x];

    if ((next == 'B' || next == '*') && estLibre(after)) {
        if (next == '*')
        {
            carte.getMap()[nextPos.y][nextPos.x] = 'O';
            carte.getMap()[afterPos.y][afterPos.x] = 'B'; // B veut dire que la caisse est sur le sol
        }
        else if(after == 'O')
        {
            carte.getMap()[nextPos.y][nextPos.x] = '.';
            carte.getMap()[afterPos.y][afterPos.x] = '*'; // * veut dire que la caisse est sur un objectif
        }
        else
        {
            carte.getMap()[nextPos.y][nextPos.x] = '.';
            carte.getMap()[afterPos.y][afterPos.x] = 'B';
        }
        m_position = nextPos;

    } else if (estLibre(next)) {
        // Déplacement simple sans boîte
        m_position = nextPos;
    }
}

void Joueur::AIUpdate(Carte& carte, std::vector<char>& path) {
    for(auto move : path)
    {
        sf::Vector2i dir(0, 0);
        if (move == 'D') dir.x = 1;
        else if (move == 'G') dir.x = -1;
        else if (move == 'H') dir.y = -1;
        else if (move == 'B') dir.y = 1;

        sf::Vector2i nextPos = m_position + dir;
        sf::Vector2i afterPos = m_position + dir * 2;

        if (nextPos.y < 0 || nextPos.y >= carte.getHauteur() ||
            nextPos.x < 0 || nextPos.x >= carte.getLargeur())
            return;

        char& current = carte.getMap()[m_position.y][m_position.x];
        char& next = carte.getMap()[nextPos.y][nextPos.x];
        char after = ' ';

        if (afterPos.y >= 0 && afterPos.y < carte.getHauteur() &&
            afterPos.x >= 0 && afterPos.x < carte.getLargeur())
            after = carte.getMap()[afterPos.y][afterPos.x];

        if ((next == 'B' || next == '*') && estLibre(after)) {
            if (next == '*')
            {
                carte.getMap()[nextPos.y][nextPos.x] = 'O';
                carte.getMap()[afterPos.y][afterPos.x] = 'B'; // B veut dire que la caisse est sur le sol
            }
            else if(after == 'O')
            {
                carte.getMap()[nextPos.y][nextPos.x] = '.';
                carte.getMap()[afterPos.y][afterPos.x] = '*'; // * veut dire que la caisse est sur un objectif
            }
            else
            {
                carte.getMap()[nextPos.y][nextPos.x] = '.';
                carte.getMap()[afterPos.y][afterPos.x] = 'B';
            }
            m_position = nextPos;

        } else if (estLibre(next)) {
            // Déplacement simple sans boîte
            m_position = nextPos;
        }
    }
}
