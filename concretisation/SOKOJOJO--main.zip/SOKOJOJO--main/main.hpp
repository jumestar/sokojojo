#include <SFML/Graphics.hpp>
#include <fstream>
#include <vector>
#include <string>

// Constantes 
const sf::Uint32 W_WIDTH{1200};
const sf::Uint32 W_HEIGHT{800};