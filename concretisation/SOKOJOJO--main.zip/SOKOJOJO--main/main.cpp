#include "main.hpp"
#include "carte.hpp"
#include "joueur.hpp"
#include "menu.hpp"
#include "game.hpp"

#include <iostream>
/*
Game.cpp : Contient la logique du jeu, y compris la gestion des entrées du joueur & l'affichage de la carte.
Carte.cpp : Gère le chargement et l'affichage de la carte
Joueur.cpp : Gère la position et le mouvement du joueur sur la carte.
Menu.cpp : Gère l'affichage du menu principal & de la sélection des niveaux & les entrées du joueur & l'affichage de la victoire.
*/

/*
à faire :

un compteur de temps

l'ia
*/

int main()
{
    sf::RenderWindow window(sf::VideoMode({W_WIDTH, W_HEIGHT}), "SOKOJOJO!");

    Menu menu(window);  // Initialisation du menu
    bool isRunning{false};  // Si le jeu est lancé
    bool isLevelSelected{false};  // Si un niveau a été sélectionné
    int selectedLevel{-1};  // Niveau sélectionné, -1 au départ

    bool victoire{false};  // Si le joueur a gagné

    window.setFramerateLimit(60);
    window.setKeyRepeatEnabled(false);  // Désactiver la répétition des touches

    
    while (window.isOpen()) {
        sf::Event event;
        bool resetRequested = false;

        
        // Gérer les événements tant que le jeu n'est pas lancé
        while (window.pollEvent(event) && !isRunning) {
            if (event.type == sf::Event::Closed)
                window.close();
            window.clear();  // Effacer l'écran pour le menu

            // Gérer les entrées dans le menu
            menu.handleInput(event);
            menu.updateSelection(event); // Mettre à jour la sélection
            isRunning = menu.getRunning();  // Vérifier si le jeu doit être lancé
            selectedLevel = menu.getSelectedOption() + 1; // Obtenir le niveau sélectionné

            menu.drawMenu();  // Dessiner le menu principal
        }

        // Si le jeu est lancé, initialiser la carte et le joueur
        if (isRunning) {
            playLevel(window, menu, selectedLevel);
            isRunning = false;
            menu.setRunning(false);
        }
    }
    return 0;
}