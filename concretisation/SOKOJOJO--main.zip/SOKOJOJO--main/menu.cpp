#include "menu.hpp"
#include <iostream>


Menu::Menu(sf::RenderWindow& window) : m_window(window) {

    loadResources();
}

void Menu::loadResources() {
    // Charger la police
    if (!m_font.loadFromFile("res/PressStart2P-Regular.ttf")) {
        std::cerr << "Erreur lors du chargement de la police" << std::endl;
    }

    // Titre
    m_title.setFont(m_font);
    m_title.setString("SOKOJOJO!");
    m_title.setCharacterSize(50);
    m_title.setFillColor(sf::Color::White);
    m_title.setPosition(m_window.getSize().x / 2 - m_title.getGlobalBounds().width / 2, 50);

    // Jouer
    m_playButton.setFont(m_font);
    m_playButton.setString("Jouer");
    m_playButton.setCharacterSize(30);
    m_playButton.setFillColor(sf::Color::White);
    m_playButton.setPosition(m_window.getSize().x / 2 - m_playButton.getGlobalBounds().width / 2, 150);

    // Quitter
    m_exitButton.setFont(m_font);
    m_exitButton.setString("Quitter");
    m_exitButton.setCharacterSize(30);
    m_exitButton.setFillColor(sf::Color::White);
    m_exitButton.setPosition(m_window.getSize().x / 2 - m_exitButton.getGlobalBounds().width / 2, 250);

    // Boutons de niveaux
    for (int i = 0; i < 6; ++i) {
        sf::Text levelButton;
        levelButton.setFont(m_font);
        levelButton.setString("Niveau " + std::to_string(i + 1));
        levelButton.setCharacterSize(30);
        levelButton.setFillColor(sf::Color::White);
        levelButton.setPosition(m_window.getSize().x / 2 - levelButton.getGlobalBounds().width / 2, 150 + i * 60);
        levelButtons.push_back(levelButton);
    }
    
    sf::Text backButton;
    backButton.setFont(m_font);
    backButton.setString("Retour");
    backButton.setCharacterSize(30);
    backButton.setFillColor(sf::Color::White);
    backButton.setPosition(m_window.getSize().x / 2 - backButton.getGlobalBounds().width / 2, 150 + 6 * 60);
    levelButtons.push_back(backButton);
}

void Menu::drawMenu() {
    m_window.clear();
    m_window.draw(m_title);

    if (isLevelSelection) {
        drawLevelSelection();  // Afficher le menu de sélection des niveaux
    } else {
        drawMainMenu();  // Afficher le menu principal
    }

    m_window.display();
}

void Menu::drawMainMenu() {
    m_window.draw(m_playButton);
    m_window.draw(m_exitButton);
}

void Menu::drawLevelSelection() {
    for (auto& levelButton : levelButtons)
        m_window.draw(levelButton); // Dessiner chaque bouton de niveau
}

void Menu::handleInput(sf::Event &event) {
    if (event.type == sf::Event::KeyPressed) {
        if (!isLevelSelection) {
            // Si on est dans le menu principal
            if (event.key.code == sf::Keyboard::Up)
                selectedOption = (selectedOption - 1 + 2) % 2;  // Naviguer entre "Jouer" et "Quitter"
            else if (event.key.code == sf::Keyboard::Down)
                selectedOption = (selectedOption + 1) % 2;
            else if (event.key.code == sf::Keyboard::Enter) {
                if (selectedOption == 0) {
                    isLevelSelection = true;  // Passer au menu de sélection de niveau
                } else if (selectedOption == 1) {
                    m_window.close();  // Quitter le jeu
                }
            }
        } 
        else
        {
            // Si on est dans le menu de sélection des niveaux
            if (event.key.code == sf::Keyboard::Up) {
                selectedOption = (selectedOption - 1 + levelButtons.size()) % (levelButtons.size());
            } 
            else if (event.key.code == sf::Keyboard::Down) {
                selectedOption = (selectedOption + 1) % (levelButtons.size());
            }
            else if (event.key.code == sf::Keyboard::Enter) {
                if (selectedOption == levelButtons.size()-1) {  // Si on appuie sur "Retour"
                    isLevelSelection = false;  // Retour au menu principal
                    selectedOption = 0;  // Réinitialiser la sélection
                } else {
                    isRunning = true;  // Lancer le jeu avec le niveau sélectionné
                }
            }
        }
    }
}

void Menu::updateSelection(sf::Event &event) {
    // Mise à jour des couleurs de sélection
    if (isLevelSelection) {
        // D'abord, remettre tous les boutons à la couleur blanche
        for (size_t i = 0; i < levelButtons.size(); ++i) {
            levelButtons[i].setFillColor(sf::Color::White);
        }

        // Appliquer la couleur jaune au bouton sélectionné
        if (selectedOption >= 0 && selectedOption < levelButtons.size()) {
            levelButtons[selectedOption].setFillColor(sf::Color::Yellow);
        }
    } else {
        // Menu principal : réinitialiser les couleurs des boutons
        m_playButton.setFillColor(sf::Color::White);
        m_exitButton.setFillColor(sf::Color::White);

        // Mettre en jaune le bouton correspondant à l'option sélectionnée
        if (selectedOption == 0) {
            m_playButton.setFillColor(sf::Color::Yellow);
        } else if (selectedOption == 1) {
            m_exitButton.setFillColor(sf::Color::Yellow);
        }
    }
}

void Menu::setRunning(bool running) {
    isRunning = running;
}

void Menu::drawVictory(sf::RenderWindow& window) {

    sf::Text victoryText;
    sf::Font font;
    if (!font.loadFromFile("res/PressStart2P-Regular.ttf")) {
        std::cerr << "Erreur de chargement de la police" << std::endl;
        return;
    }
    victoryText.setFont(font);
    victoryText.setString("VICTOIRE !");
    victoryText.setCharacterSize(50);
    victoryText.setFillColor(sf::Color::Green);

    sf::Vector2u windowSize = window.getSize();
    victoryText.setPosition(
        windowSize.x / 2 - victoryText.getGlobalBounds().width / 2,
        windowSize.y / 2 - victoryText.getGlobalBounds().height / 2
    );

    window.clear();
    window.draw(victoryText);
    window.display();
    sf::sleep(sf::seconds(3));
}
 // Pour les entrées récentes

void Menu::addInputs(sf::Keyboard::Key key) {
    if (recentInputs.size() >= 20)
        recentInputs.erase(recentInputs.begin());  // Supprime la plus ancienne
    recentInputs.push_back(key);  // Ajoute la nouvelle touche
}

std::string Menu::keyToString(sf::Keyboard::Key key) {
    switch (key) {
        case sf::Keyboard::Left: return "G";
        case sf::Keyboard::Right: return "D";
        case sf::Keyboard::Up: return "H";
        case sf::Keyboard::Down: return "B";
        default: return "?";
    }
}

void Menu::drawRestart(sf::RenderWindow& window) {
    sf::Font font;
    if (font.loadFromFile("res/PressStart2P-Regular.ttf")) {
        sf::Text restartLabel;
        restartLabel.setFont(font);
        restartLabel.setString("Restart : R");
        restartLabel.setCharacterSize(14);
        restartLabel.setFillColor(sf::Color::White);
        restartLabel.setPosition(10.f, 10.f);
        window.draw(restartLabel);
    }
}

void Menu::drawInputs(sf::RenderWindow& window) {
    sf::Font font;
    if (font.loadFromFile("res/PressStart2P-Regular.ttf")) {
        sf::Text inputLabel;
        inputLabel.setFont(font);
        inputLabel.setCharacterSize(14);
        inputLabel.setFillColor(sf::Color::White);
        inputLabel.setPosition(10.f, 30.f);

        std::string inputStr = "Inputs : ";
        int count = 0;
        for (auto key : recentInputs) {
            inputStr += keyToString(key) + " ";
            count++;

            if (count % 10 == 0)
                inputStr += "\n         "; // aligne avec "Inputs : "
        }
        inputLabel.setString(inputStr);
        window.draw(inputLabel);
    }
}