#pragma once

#include "carte.hpp"
#include "joueur.hpp"
#include "menu.hpp"
#include <SFML/Graphics.hpp>

void playLevel(sf::RenderWindow& window, Menu& menu, int selectedLevel);