#include "game.hpp"
#include <iostream>

void playLevel(sf::RenderWindow& window, Menu& menu, int selectedLevel) {
    bool resetRequested;
    bool victoire = false;

    do {
        resetRequested = false;

        std::cout << "Niveau sélectionné : " << selectedLevel << std::endl;

        Carte carte(Carte::levelFiles[selectedLevel - 1], selectedLevel);
        std::cout << "Carte chargée" << std::endl;

        Joueur joueur(carte, carte.getDepart());
        std::cout << "Joueur initialisé" << std::endl;

        sf::Event event;
        while (!victoire && window.isOpen()) {
            while (window.pollEvent(event)) {
                if (event.type == sf::Event::Closed)
                    window.close();

                if (event.type == sf::Event::KeyPressed) {
                    if (event.key.code == sf::Keyboard::R) {
                        std::cout << "Reset du niveau...\n";
                        resetRequested = true;
                        menu.resetInputs();
                        break;
                    }
                    joueur.update(carte, event.key.code);
                    menu.addInputs(event.key.code);
                }
            }

            if (resetRequested) break;

            window.clear();
            carte.draw(window);
            joueur.draw(window);
            menu.drawRestart(window);
            menu.drawInputs(window);
            window.display();

            victoire = carte.hasWon();
        }

        if (victoire) {
            menu.drawVictory(window);
            menu.resetInputs();
            std::cout << "Victoire !\n";
        }

        carte.setWon(false);
    } while (resetRequested && window.isOpen());
}
