#pragma once

#include "carte.hpp"

class AI {

    public:
        void copyMap(Carte& carte);
        void setMap(Carte& carte);

    private:
        Carte m_carte;
        std::vector<char> m_inputs;
};