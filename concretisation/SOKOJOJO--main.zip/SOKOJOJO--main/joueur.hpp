#pragma once
#include <SFML/Graphics.hpp>
#include "carte.hpp"
#include <memory>

class Joueur {
    public:
        Joueur(Carte& carte, sf::Vector2i position);
        void update(Carte& carte, sf::Keyboard::Key key);
        void draw(sf::RenderWindow& window);
        sf::Vector2i getPosition() const;
        void AIUpdate(Carte& carte, std::vector<char>& inputs);
    private:
        std::unique_ptr<sf::Texture> m_texture;  
        std::unique_ptr<sf::Sprite> m_sprite;   
        sf::Vector2i m_position;
        bool estLibre(char c) const ;
    };