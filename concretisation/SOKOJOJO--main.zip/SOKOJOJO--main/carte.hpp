#pragma once

#include <SFML/Graphics.hpp>
#include "ext/json.hpp"
#include <vector>
#include <string>

using json = nlohmann::json;

class Carte {
public:
    Carte(const std::string& filename,int levelId);
     // charge un niveau depuis un fichier JSON
    static const std::vector<std::string> levelFiles; // fichiers de niveaux disponibles

    void draw(sf::RenderWindow& window);
    
    sf::Vector2i getDepart() const { return depart; }
    int getHauteur() const { return rows; }
    int getLargeur() const { return cols; }
    int getLevelId() const { return levelId; }
    bool hasWon() const { return m_won; }
    void setWon(bool won) { m_won = won; } // Setter pour la victoire

    const std::vector<sf::Vector2i>& getMurs() const { return murs; }
    const std::vector<sf::Vector2i>& getCaisses() const { return caisses; }
    const std::vector<sf::Vector2i>& getObjectifs() const { return objectifs; }
    std::vector<std::string>& getMap() { return level; }

private:
    std::vector<std::string> level; // le plateau de jeu
    int rows = 0, cols = 0;
    const int tileSize{64};
    int levelId; // ID du niveau

    sf::Vector2i depart;
    bool m_won{false};

    std::vector<sf::Vector2i> murs;
    std::vector<sf::Vector2i> caisses;
    std::vector<sf::Vector2i> objectifs;

    // textures
    sf::Texture wallTex, floorTex, boxTex, targetTex, boxOnTargetTex;

    void loadSelectedLevel(const std::string& filename, int selectedLevelId);
    void loadTextures();
    void loadLevelFromJson(const json& levelData);
    
};